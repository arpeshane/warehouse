import { LdapConfiguration } from '../model/ldapconfiguration';
import { Location } from '@angular/common';
import { ActivatedRoute, Params } from '@angular/router';
import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class DataService {
    private webUrl = 'eem';
  private customersUrl2 = 'eem/editldapconfiguration';  // URL to web API
  private customersUrl3 = 'eem/updatecustomerbyid';
  private customersUrl4 = 'eem/deletecustomerbyid';  // URL to web API

  getLdapDetailsByID(id: number): Promise<LdapConfiguration> {
      const url = `${this.customersUrl2}/${id}`
      console.log("=============in service data==========="+url);
    return this.http.get(url)
      .toPromise()
      .then(response => response.json() as LdapConfiguration)
      .catch(this.handleError1);
  }
  private handleError1(error: any): Promise<any> {
    console.error('Error', error); // for demo purposes only
    return Promise.reject(error);
  }
    
    constructor(private http: Http) { }
    
     createLdapCofiguration(ldapConfiguration: LdapConfiguration):Observable<number> {
	    let cpHeaders = new Headers({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'});
            let options = new RequestOptions({headers: cpHeaders });
          console.log(JSON.stringify(ldapConfiguration));
          console.log("<<<<<<<<httu url>>>>>" + this.http.post(this.webUrl+"/addldapconfiguration", ldapConfiguration, options).map(success => success.status).catch(this.handleError));
       return this.http.post(this.webUrl+"/addldapconfiguration", ldapConfiguration)
               .map(success => success.status)
               .catch(this.handleError);
               
  
}

    getAllLdapConfiguration(): Observable<LdapConfiguration[]> {
        return this.http.get(this.webUrl + "/viewldapconfiguration").map(this.extractData)
            .catch(this.handleError);
       }
       
      updateLdapDetails(ldapConfiguration: LdapConfiguration):Observable<number> {
          const url = `${this.customersUrl3}/${ldapConfiguration.id}`;
       let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: cpHeaders });
        return this.http.put(url, ldapConfiguration, options)
               .map(success => success.status)
               .catch(this.handleError);
        
    }
    
    deleteLdapDetails(id: number): Observable<number> {
        const url = `${this.customersUrl4}/${id}`;
        console.log("=====Id in deleteService=====" + id);
        let cpHeaders = new Headers({'Content-Type': 'application/json'});
        let options = new RequestOptions({headers: cpHeaders});
        return this.http.delete(url).map(success => success.status)
            .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body;
    }
    private handleError(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.status);
    }
}
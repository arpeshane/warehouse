import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {IndividualCustomer} from '../model/individual-customer.model';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'  })
};
@Injectable()
export class IndividualCustomerService {  
          
 selectedcustomer : IndividualCustomer; 
 selectedcustlist  : IndividualCustomer[];

  constructor(private http:HttpClient) { }
  
 private userUrl = 'eem';
 
  public createIndCust(cust : IndividualCustomer) {
    return this.http.post<IndividualCustomer>(this.userUrl+"/createcust", cust);
  }
  public getCustDetails() {
    return this.http.get<IndividualCustomer[]>(this.userUrl+"/getcust");
  }
  public updateCust(cust:IndividualCustomer) {
  return this.http.post<IndividualCustomer>(this.userUrl+"/updatecust",cust);  
  }
  public generateReport(cust:IndividualCustomer, startdate:string, enddate:string) {
      const url = `${this.userUrl}/genreport/${cust.customerId}/${startdate}/${enddate}`;
      return this.http.get<string>(url, httpOptions).map((Success) =>{
           return Success; 
       } );
}
  public getCustomersName(){
      return this.http.get<any[]>(this.userUrl+"/custname", httpOptions)  ;
  }
}

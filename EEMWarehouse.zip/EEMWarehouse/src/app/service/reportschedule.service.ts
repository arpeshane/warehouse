import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {ReportSchedule} from '../model/reportschedule'
import {LogConfiguration} from '../model/logconfiguration'
import {SummaryReportConfiguration} from '../model/summaryreportconfiguration'



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'  })
};

@Injectable()
export class ReportscheduleService {
     selectedReportSchedule:ReportSchedule;
    selectedReportSchedules:ReportSchedule[];
    
    selectedLogConfiguration:LogConfiguration;
    selectedLogConfigurations:LogConfiguration[];
    
    selectedSummaryReportConfiguration:SummaryReportConfiguration;
    selectedSummaryReportConfigurations:SummaryReportConfiguration[];

  constructor(private http:HttpClient) { }
  private userUrl = '/eem';
  
    public createReportConfiguration(selectedReportSchedule: ReportSchedule) {
        selectedReportSchedule.report_type='Daily';
        console.log("===selectedschedulereport in service==" + JSON.stringify(selectedReportSchedule));
        return this.http.post<ReportSchedule>(this.userUrl + "/createreportschedule", selectedReportSchedule);
    }
    
    public showReportConfiguration(){
        return this.http.get<ReportSchedule>(this.userUrl+"/showreportschedule");
    }
     public updateReportConfiguration(selectedReportSchedule: ReportSchedule){
        selectedReportSchedule.report_type='Daily';
          return this.http.post<ReportSchedule>(this.userUrl+"/updatereportschedule",selectedReportSchedule);
      }

    public createLogConfiguration(selectedLogConfiguration: LogConfiguration) {
        console.log("===createLogConfiguration in service==" + JSON.stringify(selectedLogConfiguration));
        return this.http.post<LogConfiguration>(this.userUrl + "/createlogconfiguration", selectedLogConfiguration);
    }
    
    public showLogConfiguration(){
        return this.http.get<LogConfiguration>(this.userUrl+"/showlogconfiguration");
    }
    
    public updateLogConfiguration(selectedLogConfiguration: LogConfiguration){
        return this.http.post<ReportSchedule>(this.userUrl+"/updatelogconfiguration",selectedLogConfiguration);
      }
    
    public createSummaryReportConfiguration(selectedSummaryReportConfiguration: SummaryReportConfiguration) {
        console.log("===createSummaryReportConfiguration in service==" + JSON.stringify(selectedSummaryReportConfiguration));
        return this.http.post<SummaryReportConfiguration>(this.userUrl + "/createsummaryreportconfiguration", selectedSummaryReportConfiguration);
    }
    
    public showSummaryReportConfiguration(){
        return this.http.get<SummaryReportConfiguration>(this.userUrl+"/showsummaryreportconfiguration");
    }
    
    public updateSummaryReportConfiguration(selectedSummaryReportConfiguration: SummaryReportConfiguration){
        return this.http.post<ReportSchedule>(this.userUrl+"/updatesummaryreportconfiguration",selectedSummaryReportConfiguration);
      }

}

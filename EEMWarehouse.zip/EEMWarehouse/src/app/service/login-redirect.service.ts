import {Injectable} from '@angular/core';
import {CanActivate, Router} from '@angular/router';
@Injectable()
export class LoginRedirectService {

    constructor(private router: Router) {}
    canActivate(): boolean {
        if (sessionStorage.getItem('token')) {
            this.router.navigateByUrl('/home');
            return false;
        }
        else {
            return true;
        }
    }

}

import { TestBed, inject } from '@angular/core/testing';

import { ReportscheduleService } from './reportschedule.service';

describe('ReportscheduleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReportscheduleService]
    });
  });

  it('should be created', inject([ReportscheduleService], (service: ReportscheduleService) => {
    expect(service).toBeTruthy();
  }));
});

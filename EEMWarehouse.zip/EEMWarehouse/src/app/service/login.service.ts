import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import {UserLogin} from '../model/userlogin';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
 
};
@Injectable()
export class LoginService {
  private messageSource = new BehaviorSubject<string>("");
  currentMessage = this.messageSource.asObservable();
    private loginUrl = 'eem/login';

  constructor(private http: HttpClient) {  }
   changeMessage(login: string) {
    this.messageSource.next(login)
  }
  
   public checkUsers(user: UserLogin){
       return this.http.post<string>(this.loginUrl, user, httpOptions).map((success) =>{
           return success; 
       } );
  }
  
  
  
}

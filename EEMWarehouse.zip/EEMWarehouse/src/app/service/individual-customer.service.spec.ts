import { TestBed, inject } from '@angular/core/testing';

import { IndividualCustomerService } from '../service/individual-customer.service';

describe('IndividualCustomerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [IndividualCustomerService]
    });
  });

  it('should be created', inject([IndividualCustomerService], (service: IndividualCustomerService) => {
    expect(service).toBeTruthy();
  }));
});

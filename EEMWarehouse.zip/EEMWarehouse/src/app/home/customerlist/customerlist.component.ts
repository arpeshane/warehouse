import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {IndividualCustomer} from '../../model/individual-customer.model';
import {IndividualCustomerService} from "../../service/individual-customer.service";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
 customer : IndividualCustomer
 constructor(private router: Router, public customerService: IndividualCustomerService, private toastr: ToastrService) { }
  ngOnInit() {
      this.customerService.getCustDetails()
      .subscribe( data => {
          this.customerService.selectedcustlist = data;
      });
     
  };
  addNewCust(){
      this.router.navigateByUrl('home/addcustomer');
  }
  getCust(customer : IndividualCustomer){
     this.customerService.selectedcustomer=Object.assign({}, customer); 
      this.router.navigateByUrl('home/editcustomer');
  }
  getGenReport(customer : IndividualCustomer){
      this.customer = customer;
  }
  genReport(){
      this.customerService.generateReport(this.customer, $("#starttime").val().toString(), $("#endtime").val().toString()).subscribe( data => {
            let result=data != null?JSON.stringify(data):null;           
         if (result != null && JSON.parse(result)['success'] == 'loginsuccess') 
         this.toastr.success("Report has been sent to customer's mail!", 'Report Generated!');
       else
           this.toastr.error("An error has been occured", "Something Wrong!"); 
     });
}
enableReport(value : string, customerId : number){
     if (value=="No"){
        $("#"+customerId).prop('disabled', true)
    }if (value=="Yes"){
        $("#"+customerId).removeAttr('disabled');
    }else{
      $("#"+customerId).prop('disabled', true)   
    }
}
}

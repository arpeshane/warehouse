import { Component, OnInit } from '@angular/core';
import {LoginService} from '../service/login.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  message:string;
  constructor(private login: LoginService,private router: Router) { }

  ngOnInit() {
      this.login.currentMessage.subscribe(message => this.message = message);
      this.message=sessionStorage.getItem('token');
      $(".collapse_nav").click(function () {
          $(this).parent().parent('.dash_left_section').toggleClass('hide_menu');
          $('.dash_right_section').toggleClass('srink_area');
      });
      $('.drop_menu .plus').click(function () {
          $("#dashboard").removeClass('active');
          $(this).parent(".drop_menu").toggleClass('open');
      });
      $('#dashboard').click(function () {
          $("#dashboard").addClass('active');
          $(".drop_menu").removeClass('open');
      });
  }
  logout(){
      sessionStorage.removeItem("token");
      this.router.navigate(['login']);
}
}

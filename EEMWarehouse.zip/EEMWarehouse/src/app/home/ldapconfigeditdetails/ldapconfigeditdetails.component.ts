import { Component, OnInit } from '@angular/core';
import { LdapConfiguration } from '../../model/ldapconfiguration';
import { DataService } from '../../service/data.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import 'rxjs/add/operator/switchMap';
import {FormControl, FormGroup, Validators} from '@angular/forms'

@Component({
  selector: 'app-ldapconfigeditdetails',
  templateUrl: './ldapconfigeditdetails.component.html',
  styleUrls: ['./ldapconfigeditdetails.component.css']
})
export class LdapconfigeditdetailsComponent implements OnInit {
     ldapConfiguration=new LdapConfiguration();
     statusCode: number;
     ldapForm=new FormGroup({
      id: new FormControl(),   
      serverurl: new FormControl(),   
      basedn: new FormControl(), 
      username:new FormControl(),  
      password:new FormControl(),  
      userdnpattern:new FormControl()  
      });
     constructor(private dataService: DataService,private route: ActivatedRoute,private location: Location)
     { }
     
  ngOnInit() {
        console.log("====edit==========")
       this.route.params
           .switchMap((params: Params) => this.dataService.getLdapDetailsByID(+params['id']))
           .subscribe(ldapConfiguration => this.ldapForm.setValue({
               id: ldapConfiguration.id,
               serverurl: ldapConfiguration.serverurl, basedn: ldapConfiguration.basedn,
               username: ldapConfiguration.username, password: ldapConfiguration.password, userdnpattern: ldapConfiguration.userdnpattern
           }),
               errorCode => this.statusCode = errorCode
           );
       }
     onSubmitLdapFormUpdate(){
       let formval = this.ldapForm.value;
         console.log("============onArticleFormUpdate1233===============" + JSON.stringify(formval));
        this.dataService.updateLdapDetails(formval).subscribe(successCode=>{
            this.statusCode=successCode;
            //this.goBack();
        },
            errorCode => this.statusCode=errorCode
        );
    }
    goBack() {
    this.location.back();
     }

}

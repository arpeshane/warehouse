import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdapconfigeditdetailsComponent } from './ldapconfigeditdetails.component';

describe('LdapconfigeditdetailsComponent', () => {
  let component: LdapconfigeditdetailsComponent;
  let fixture: ComponentFixture<LdapconfigeditdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdapconfigeditdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdapconfigeditdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

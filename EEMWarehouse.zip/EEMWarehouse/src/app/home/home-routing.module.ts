import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import { HomeComponent } from './home.component';
import {IndividualCustomerComponent} from './individual-customer/individual-customer.component';
import { LdapconfigurationComponent } from './ldapconfiguration/ldapconfiguration.component';
import {GeneralConfigurationComponent} from './general-configuration/general-configuration.component';
import { LdapconfigurationdetailsComponent } from './ldapconfigurationdetails/ldapconfigurationdetails.component';
import { LdapconfigeditdetailsComponent } from './ldapconfigeditdetails/ldapconfigeditdetails.component';
import { EemDailyReportsScheduleComponent } from './eem-daily-reports-schedule/eem-daily-reports-schedule.component';
import {CustomerlistComponent} from './customerlist/customerlist.component';
import { EnsureAuthenticatedService } from '../service/ensure-authenticated.service';
const homeRoutes: Routes = [
    {
        path: '',
        component: HomeComponent,
        children: [
            {path: './', component: HomeComponent},
            {path: 'addcustomer', component: IndividualCustomerComponent}, 
            {path: 'editcustomer', component: IndividualCustomerComponent}, 
            {path: 'customerlist', component: CustomerlistComponent},
            {path: 'generalconfig', component: GeneralConfigurationComponent}, 
            {path: 'ldapconfig', component: LdapconfigurationComponent},
            {path: 'viewldapconfig', component: LdapconfigurationdetailsComponent}, 
            {path: 'detail/:id', component: LdapconfigeditdetailsComponent}, 
            {path: 'dailyschedulereport', component: EemDailyReportsScheduleComponent}, 

        ],
         canActivate: [EnsureAuthenticatedService]
    }
];
@NgModule({
    imports: [          
        RouterModule.forChild(homeRoutes)
    ],
    exports: [
        RouterModule,
        
        
    ]
})
export class HomeRoutingModule { }

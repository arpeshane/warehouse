import { Component, OnInit } from '@angular/core';
import { LdapConfiguration } from '../../model/ldapconfiguration';
import { DataService } from '../../service/data.service';
import { Location } from '@angular/common';
import { ActivatedRoute, Params } from '@angular/router';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-ldapconfigurationdetails',
  templateUrl: './ldapconfigurationdetails.component.html',
  styleUrls: ['./ldapconfigurationdetails.component.css']
})
export class LdapconfigurationdetailsComponent implements OnInit {
    ldapconfigurations: LdapConfiguration[];
     statusCode: number;
    ldapconfiguration=new  LdapConfiguration();
    
     constructor(private dataService: DataService, private route: ActivatedRoute) {
         console.log("==========constructor run============");
       }
  
  ngOnInit() {
      this.getLdapDetails();
  }
  
  
   getLdapDetails(){
       console.log("=============hiiii================");
        this.dataService.getAllLdapConfiguration()
		  .subscribe(
                data => this.ldapconfigurations = data,
                errorCode =>  this.statusCode = errorCode); 
    }
     deleteLdapDetails(id:number){
        console.log("=======<<delete article>>======");
        this.dataService.deleteLdapDetails(id).subscribe(successCode=>{
            this.statusCode=204;
            this.refresh();
        },
            errorCode => this.statusCode=errorCode
        );
    }
    refresh(): void {
    window.location.reload();
}
  

}

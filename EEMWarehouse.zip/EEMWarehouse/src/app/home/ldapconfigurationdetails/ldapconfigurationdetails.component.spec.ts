import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdapconfigurationdetailsComponent } from './ldapconfigurationdetails.component';

describe('LdapconfigurationdetailsComponent', () => {
  let component: LdapconfigurationdetailsComponent;
  let fixture: ComponentFixture<LdapconfigurationdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdapconfigurationdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdapconfigurationdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

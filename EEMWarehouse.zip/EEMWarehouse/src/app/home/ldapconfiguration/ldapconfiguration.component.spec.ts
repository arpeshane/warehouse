import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdapconfigurationComponent } from './ldapconfiguration.component';

describe('LdapconfigurationComponent', () => {
  let component: LdapconfigurationComponent;
  let fixture: ComponentFixture<LdapconfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdapconfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdapconfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { LdapConfiguration } from '../../model/ldapconfiguration';
import { Location } from '@angular/common';
import { DataService } from '../../service/data.service';
import {FormControl, FormGroup, Validators} from '@angular/forms'

@Component({
  selector: 'app-ldapconfiguration',
  templateUrl: './ldapconfiguration.component.html',
  styleUrls: ['./ldapconfiguration.component.css']
})
export class LdapconfigurationComponent implements OnInit {
    
   allConfiguration: LdapConfiguration[]; 
    statusCode: number;
     ldapForm=new FormGroup({
          serverurl: new FormControl(),   
          basedn: new FormControl(), 
          username:new FormControl(),  
          password:new FormControl(),  
          userdnpattern:new FormControl()  
      });
 constructor(private dataService: DataService) { }

  ngOnInit() {
       
  }
  
  getAllLdapConfiguration(){
      this.dataService.getAllLdapConfiguration()
		  .subscribe(
                data => this.allConfiguration = data,
                errorCode =>  this.statusCode = errorCode); 
  }
  onSubmit(){
      let formval = this.ldapForm.value;
      console.log("====formval==="+JSON.stringify(formval));
       this.dataService.createLdapCofiguration(formval).subscribe(successCode => {
                this.statusCode = successCode;
                this.backToCreateLdapConf();  
            },
                errorCode => this.statusCode = errorCode
            );
  }
   backToCreateLdapConf() {
      this.ldapForm.reset();	  
   }
}

import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {NgForm} from '@angular/forms';
import {IndividualCustomerService} from "../../service/individual-customer.service";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-individual-customer',
  templateUrl: './individual-customer.component.html',
  styleUrls: ['./individual-customer.component.css']
})

export class IndividualCustomerComponent implements OnInit {
  constructor(private customerService: IndividualCustomerService, private toastr: ToastrService, private router: Router) { }
 customernames : any[];
  ngOnInit() {
        this.customerService.getCustomersName()
        .subscribe( data => {
            if(data!=null)
            this.customernames = data;
            else{
                this.customernames = ["No customer found"];
                $('#custName').attr("disabled", "disabled");
            }
            
        }); 
        if(this.router.url=="/home/addcustomer"){
            this.resetForm();
            $('#customername').css("display", "none");
            $('#custName').removeAttr("style");
        }
         else{
            $('#customername').removeAttr("style");
            $('#custName').css("display", "none");
            $('#addcust').val("Update");
            $('#custhead').html("Update Customer");
         }
   };
    resetForm(form?: NgForm) {
    if (form != null)
      form.reset();
    this.customerService.selectedcustomer = {
    customerId: null,
    custName: '',
    custMailId: '',
    weekStartDay: '',
    weekEndDay: '',
    createDate:'', 
    dailyScheduledTime: '',
    emailReportTo: '',
    emailAlertsTo: '',
    custStatus: '',
    deactivatedBy: '',
    reasonForDeactivation: '',
    custDeactivationDate: '',
    createdBy: '',
    createdDate: '',
    modifiedBy: '',
    lastModifiedDate: ''
    }
  }
  createCust(form : NgForm): void {
      if (form.value.customerId == null) {
         this.customerService.createIndCust(form.value)
        .subscribe( data => {
          this.resetForm(form);
          this.toastr.success('Customer Updated Successfully!', 'Record Added');
        })
    }else{
          this.customerService.updateCust(form.value)
        .subscribe(data => {
        this.resetForm(form);
        this.toastr.success('Customer Updated Successfully!', 'Record Updated'); 
        this.router.navigateByUrl('home/customerlist');
      });
    }
  };  

}

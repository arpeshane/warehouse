import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {NgForm} from '@angular/forms';
import {ReportSchedule} from '../../model/reportschedule'
import {ReportscheduleService} from '../../service/reportschedule.service';
import { ToastrService } from 'ngx-toastr';
import { Location } from '@angular/common';

@Component({
  selector: 'app-general-configuration',
  templateUrl: './general-configuration.component.html',
  styleUrls: ['./general-configuration.component.css']
})
export class GeneralConfigurationComponent implements OnInit {

constructor(private reportscheduleService:ReportscheduleService,private toastr: ToastrService, private router: Router,private location: Location) { }

ngOnInit() {
this.reportscheduleService.showReportConfiguration()
            .subscribe(data => {
                this.reportscheduleService.selectedReportSchedule = data;
                console.log("===selectedReportSchedules Value=====" + JSON.stringify(data));
            });
            
this.reportscheduleService.showLogConfiguration().subscribe(data => {
        this.reportscheduleService.selectedLogConfiguration = data;
                console.log("===selectedLogConfigurations Value=====" + JSON.stringify(data));

});
    this.reportscheduleService.showSummaryReportConfiguration()  .subscribe(data => {
        this.reportscheduleService.selectedSummaryReportConfiguration = data;
                console.log("===selectedSummaryReportConfigurations Value=====" + JSON.stringify(data));

});
}
//  resetForm(form?: NgForm) {
//     if (form != null){
//         form.reset(); 
//         this.reportscheduleService.selectedReportSchedule={
//           sno:null,
//           time_zone:'',
//           scheduled_time:'',
//           report_type:''          
//         }
////         this.reportscheduleService.selectedLogConfiguration={
////             sno_log:null,
////             no_of_days:''
////             
////         }
////         this.reportscheduleService.selectedSummaryReportConfiguration={
////             sno_rep:null,
////             email_ids:''
////         }
//     }  
//  }


   createReportConfiguration(form : NgForm){
     
       console.log("===Form Value=====" + JSON.stringify(form.value));
       if (form.value.sno == "" || form.value.sno == null) {
           this.reportscheduleService.createReportConfiguration(form.value).subscribe(data => {
              this.toastr.success('Record Inserted Successfully', 'Record Added');
       console.log("======form data======"+form.value);
               console.log("Record inserted successfully");
              });
       }
       else {
          this.reportscheduleService.updateReportConfiguration(form.value).subscribe(data => {
               this.toastr.success('Record updated Successfully', 'Record Updated');
              });
     }
   }
   
    createLogConfiguration(form : NgForm){
        console.log("===Form Value=====" + JSON.stringify(form.value));
       if (form.value.sno_log == "" || form.value.sno_log == null) {
           this.reportscheduleService.createLogConfiguration(form.value).subscribe(data => {
              this.toastr.success('Record Inserted Successfully', 'Record Added');
       console.log("======form data======"+form.value);
               console.log("Record inserted successfully");
              });
       }
       else {
          this.reportscheduleService.updateLogConfiguration(form.value).subscribe(data => {
               this.toastr.success('Record updated Successfully', 'Record Updated');
              });
     }
    }
    
    createSummaryReportConfiguration(form : NgForm){
        console.log("===Form Value=====" + JSON.stringify(form.value));
       if (form.value.sno_rep == "" || form.value.sno_rep==null) {
           this.reportscheduleService.createSummaryReportConfiguration(form.value).subscribe(data => {
              this.toastr.success('Record Inserted Successfully', 'Record Added');
       console.log("======form data======"+form.value);
               console.log("Record inserted successfully");
             });
       }
       else {
          this.reportscheduleService.updateSummaryReportConfiguration(form.value).subscribe(data => {
               this.toastr.success('Record updated Successfully', 'Record Updated');
              });
     }
    }
}

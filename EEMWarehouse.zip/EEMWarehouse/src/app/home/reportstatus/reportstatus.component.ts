import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportstatus',
  templateUrl: './reportstatus.component.html',
  styleUrls: ['./reportstatus.component.css']
})
export class ReportstatusComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }

}

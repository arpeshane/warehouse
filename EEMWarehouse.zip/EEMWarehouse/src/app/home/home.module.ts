import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {HomeComponent} from './home.component';
import {HomeRoutingModule} from './/home-routing.module';
import {CustomerlistComponent} from './customerlist/customerlist.component';
import {EemDailyReportsScheduleComponent} from './eem-daily-reports-schedule/eem-daily-reports-schedule.component';
import {IndividualCustomerComponent} from './individual-customer/individual-customer.component';
import {LdapconfigeditdetailsComponent} from './ldapconfigeditdetails/ldapconfigeditdetails.component';
import {LdapconfigurationComponent} from './ldapconfiguration/ldapconfiguration.component';
import {LdapconfigurationdetailsComponent} from './ldapconfigurationdetails/ldapconfigurationdetails.component';
import {IndividualCustomerService} from "../service/individual-customer.service";
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {ReportstatusComponent} from './reportstatus/reportstatus.component';
import {ReportscheduleService} from '../service/reportschedule.service';

import * as $ from 'jquery';
import {GeneralConfigurationComponent} from './general-configuration/general-configuration.component';
@NgModule({
    imports: [
        CommonModule,
        HomeRoutingModule,
        FormsModule,

    ],
    providers: [IndividualCustomerService, ReportscheduleService],
    declarations: [HomeComponent, CustomerlistComponent, EemDailyReportsScheduleComponent, IndividualCustomerComponent, LdapconfigeditdetailsComponent, LdapconfigurationComponent, LdapconfigurationdetailsComponent, ReportstatusComponent, GeneralConfigurationComponent]
})
export class HomeModule {}

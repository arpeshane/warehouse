import { Component, OnInit } from '@angular/core';
import { ReportscheduleService } from '../../service/reportschedule.service';
@Component({
  selector: 'app-eem-daily-reports-schedule',
  templateUrl: './eem-daily-reports-schedule.component.html',
  styleUrls: ['./eem-daily-reports-schedule.component.css']
})
export class EemDailyReportsScheduleComponent implements OnInit {

  constructor(private reportscheduleService: ReportscheduleService) { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EemDailyReportsScheduleComponent } from './eem-daily-reports-schedule.component';

describe('EemDailyReportsScheduleComponent', () => {
  let component: EemDailyReportsScheduleComponent;
  let fixture: ComponentFixture<EemDailyReportsScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EemDailyReportsScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EemDailyReportsScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

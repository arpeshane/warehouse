export class ReportSchedule{
    sno:string;
    time_zone:string;
    scheduled_time:string;
    report_type:string;
}

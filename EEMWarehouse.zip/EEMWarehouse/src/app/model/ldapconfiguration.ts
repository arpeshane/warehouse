export class LdapConfiguration {
    id:number;
    serverurl:string;
    basedn:string;
    username:string;
    password:string;
    userdnpattern:string;
}

export class LogConfiguration{
    sno_log:number;
    no_of_days:string;
}

export class IndividualCustomer {
    customerId: number;
    custName: string;
    custMailId: string;
    weekStartDay: string;
    weekEndDay: string;
    createDate: string;
    dailyScheduledTime: string;
    emailReportTo: string;
    emailAlertsTo: string;
    custStatus: string;
    deactivatedBy: string;
    reasonForDeactivation: string;
    custDeactivationDate: string;
    createdBy: string;
    createdDate: string;
    modifiedBy: string;
    lastModifiedDate: string;
}
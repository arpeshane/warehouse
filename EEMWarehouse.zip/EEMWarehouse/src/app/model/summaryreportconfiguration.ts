export class SummaryReportConfiguration{
    sno_rep:number;
    email_ids:string;
}

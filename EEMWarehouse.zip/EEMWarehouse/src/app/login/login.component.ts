import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {LoginService} from '../service/login.service';
import {UserLogin} from '../model/userlogin';
import {NgForm} from '@angular/forms';
import { CommonModule } from '@angular/common';  
import { BrowserModule } from '@angular/platform-browser';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

     user= new UserLogin;
     message : string;    
    
    constructor(private loginService: LoginService, private router: Router) {}

    ngOnInit() {
        this.loginService.currentMessage.subscribe(message => this.message = message);
        this.message='';
     }
         login()  {
        if (this.user.username != undefined || this.user.password != undefined){
            this.loginService.checkUsers(this.user)
        .subscribe( data => { 
            let result=data != null?JSON.stringify(data):null;           
            if (result != null && JSON.parse(result)['success'] == 'loginsuccess') {
                this.message = this.user.username;
                this.newMessage();
                sessionStorage.setItem('token', this.user.username);
                this.router.navigate(['home']);
            }else{
                 this.message = "Incorrect Username and Password !"
                this.newMessage();
                this.router.navigate(['login']);
             }
         });
        }
//        else{
//            this.message = "Username and Password can not be empty !";
//        }
  };
    
     newMessage() {
         this.loginService.changeMessage(this.message);
  }
}

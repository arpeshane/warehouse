import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AppRoutingModule} from "./app-routing.module";
import {RouterModule, Routes} from '@angular/router';
import {AppComponent} from './app.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {LoginService} from './service/login.service';
import {HttpClientModule} from '@angular/common/http';
import {IndividualCustomerService} from "./service/individual-customer.service";
import {ToastrModule} from 'ngx-toastr';
import {HttpModule} from '@angular/http';
import {DataService} from './service/data.service';
import { LoginRedirectService } from './service/login-redirect.service';
import { EnsureAuthenticatedService } from './service/ensure-authenticated.service';
import {enableProdMode} from '@angular/core';
import { NotFoundComponent } from './not-found/not-found.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import * as $ from 'jquery';

@NgModule({
    declarations: [
        AppComponent,
        NotFoundComponent,
    ],
    imports: [       
        BrowserModule,
        BrowserAnimationsModule,       
        FormsModule,        
        AppRoutingModule,
        HttpClientModule,
        HttpModule,
        ReactiveFormsModule,
        NgbModule.forRoot(),
        ToastrModule.forRoot(),
        AngularFontAwesomeModule
    ],
    providers: [LoginService, IndividualCustomerService, DataService,LoginRedirectService,EnsureAuthenticatedService],
    bootstrap: [AppComponent]
})
export class AppModule {}

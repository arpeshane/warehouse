
$(document).ready(function () {


    $('#home_slider').owlCarousel({
        loop: true,
        dots: false,
        autoplay: true,
        margin: 0,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            },
        }





    })

    $('#peopel_slider').owlCarousel({
        loop: true,
        dots: false,
        autoplay: true,
        margin: 0,
        nav: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 4
            },
        }





    })


//    $(".collapse_nav").click(function () {
//        $(this).parent().parent('.dash_left_section').toggleClass('hide_menu');
//        $('.dash_right_section').toggleClass('srink_area');
//    });
//    $('.drop_menu .plus').click(function () {
//        $("#dashboard").removeClass('active');
//        $(this).parent(".drop_menu").toggleClass('open');
//    });
//    $('#dashboard').click(function () {
//        $("#dashboard").addClass('active'); 
//        $(".drop_menu").removeClass('open');
//    });

});

